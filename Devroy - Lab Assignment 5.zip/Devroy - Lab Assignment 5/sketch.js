function setup() {
  createCanvas(400, 400);
  background (220);
  rect(50, 50, 80, 60);
  ellipse(200,75,70);
  ellipseMode (RADIUS);
  ellipse(100, 200, 80, 80);
}

function draw() {
  if (keyIsPressed) {
    if (key == 'x') {
          fill('green');
        } 
          else {
        fill ('lime');
        }
    }
  ellipse(100, 200, 80, 80);
  }

  
function mousePressed() {
    background(220);
  if ((mouseX > 50) && (mouseX < 50+80) && (mouseY > 50) && (mouseY < 50+60)) { 
    fill('navy');
  }
  else {
    fill ('blue');
  }
  if ((mouseX > 165) && (mouseX < 165+70) && (mouseY > 40) && (mouseY < 40+70)) { 
    fill('lightblue');
  }
  else {
    fill ('blue');
  }
  ellipse(200,75,70);
    rect(50, 50, 80, 60);
  rect(50, 50, 80, 60);
    ellipse(200,75,70);
}
