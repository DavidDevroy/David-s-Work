let gui;
let button1;
let slider1;
let t;


function setup() {
  createCanvas(400, 400);

  gui = createGui();
  t = createToggle("Toggle", 100, 50, 200, 50);
  button1 = createButton("Button", 125, 250);
  slider1 = createSlider("Slider", 100, 150);
  gui.loadStyle("Blue");
}

function draw() {
  background(220);

  drawGui();
  //drawGui();

  if (button1.isPressed) {
    print(button1.label + " is pressed.");
  }
  if (slider1.isChanged) {
    print(slider1.label + " = " + slider1.val);
  }
  if (t.val) {
    fill(150, 75, 225);
    ellipse(200, 350, 100);
  }
}