let Grassland;
let PBJTgif;
let sunimg
function preload(){
  Grassland = loadImage('https://images.pexels.com/photos/8156827/pexels-photo-8156827.jpeg');
  PBJTgif = loadImage('https://media1.giphy.com/media/v1.Y2lkPTc5MGI3NjExZjlha3Q0dDE1emdsYmI3bXBzbzQybjRzZTJ4bTRzdGZvdnVoaTJoMCZlcD12MV9pbnRlcm5hbF9naWZfYnlfaWQmY3Q9cw/3rgXBHrMCMTJsdc6C4/giphy.gif');
  sunimg = loadImage('https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcThZnQmck2mpQ708HhUjZ488gT4twktS0n-Qg&s')
}

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  image (Grassland, 0,0,width,height)
  image (PBJTgif, mouseX-50,150, 150, 150);
  image (sunimg,mouseX-100, 0, 75, 75);
  textFont('Gotham');
  stroke(0);
  textSize(16);
  fill('red');
  text('PEANUT BUTTER JELLY TIME!!', 85, 125, 400, 50)
}