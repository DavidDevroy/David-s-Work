let gui;
let button1;
let slider1;
let t;
let spaceshipImage;
let pipes = [];
let pipeWidth = 50;
let pipeGap = 100;
let pipeSpeed = 3;
let score = 0;
let spaceshipX = 40;
let gameOver = false;

function preload(){
  spaceshipImage = loadImage('https://static.vecteezy.com/system/resources/previews/021/194/993/original/spaceship-in-pixel-art-style-vector.jpg');
}

function setup() {
  createCanvas(400, 400);

  gui = createGui();
  
}

function draw() {
  background('black');
  drawGui();
  slider1 = createSliderV("Slider", 2, 2, 32, 396, 0, 345);
  gui.loadStyle("Blue");
  image (spaceshipImage,spaceshipX, slider1.val, 55, 55);
  
  if (gameOver) {
    background(255, 0, 0);
    textSize(32);
    fill(255);
    text("Game Over!", width / 2 - 80, height / 2);
    return;
  }
   
  if (frameCount % 90 === 0) {
    let pipeHeight = random(50, 200);
      pipes.push({ x: width, top: pipeHeight, bottom: pipeHeight + pipeGap           });
  }
    
  for (let i = pipes.length - 1; i >= 0; i--) {
    pipes[i].x -= pipeSpeed;
    fill('grey');
    rect(pipes[i].x, 0, pipeWidth, pipes[i].top);
    rect(pipes[i].x, pipes[i].bottom, pipeWidth, height - pipes[i].bottom);
    if (pipes[i].x + pipeWidth < 0) {
      pipes.splice(i, 1);
    }
    if (!pipes[i].passed && pipes[i].x + pipeWidth < spaceshipX) {
      score++;
      pipes[i].passed = true; 
    }
    if(
      spaceshipX < pipes[i].x + pipeWidth &&
      spaceshipX + 20 > pipes[i].x &&
      (slider1.val < pipes[i].top || slider1.val + 20 > pipes[i].bottom)
    ) {
      gameOver = true;
    }
  }
  
  if (slider1.isChanged) {
    print(slider1.label + " = " + slider1.val);
  }
  
  fill('red');
  textSize(24);
  text("Score: " + score, 275, 380);
  
}