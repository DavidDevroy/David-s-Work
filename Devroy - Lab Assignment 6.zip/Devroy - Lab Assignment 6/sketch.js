let myArray = [0,0];
function setup() {
  createCanvas(400, 400);
  let mtDewFlavors = ['voltage', 'codered', 'bajablast','majormelon','original'];
  print(mtDewFlavors.length);
  
}

function draw() {
  background('purple');
  let forArray = []; 
  
  fill('royalblue');
  rect(25,300,100,100);
  rect(150,300,100,100);
  rect(275,300,100,100);
  triangle(25, 300, 125, 300, 75, 225);
  triangle(150, 300, 250, 300, 200, 225);
  triangle(275, 300, 375, 300, 325, 225);
  
  for(let i=25; i<125;i+=20){
    forArray.push(i);
  }
 
  for(let n=0; n<forArray.length;n++){
    forArray[n] += random(-2,2);
    fill('orange');
    circle(forArray[n],390,20);
  }
  
  for(let i=150; i<250;i+=20){
    forArray.push(i);
  }
  
  for(let n=0; n<forArray.length;n++){
    forArray[n] += random(-2,2);
    fill('orange');
    circle(forArray[n],390,20);
  }
  
  for(let i=275; i<375;i+=20){
    forArray.push(i);
  }
  
  for(let n=0; n<forArray.length;n++){
    forArray[n] += random(-2,2);
    fill('orange');
    circle(forArray[n],390,20);
  }
  
  if (mouseIsPressed) {
    myArray[0] = mouseX; 
    myArray[1] = mouseY; 
  }
  fill('darkblue');
  ellipse(myArray[0],myArray[1],80,80);
}

